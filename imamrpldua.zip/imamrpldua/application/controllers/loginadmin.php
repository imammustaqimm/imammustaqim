<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class loginadmin extends CI_Controller {
    public function index(){
        $this->load->view('templates/header');
        $this->load->view('templates/navbar');
        $this->load->view('admin/login');
    }

    public function proses(){
        $post = $this->input->post(null, true);
        if(isset($post['login'])){
            $this->load->model('admin_m');
            $query = $this->admin_m->login($post);

            if($query->num_rows() > 0){
                $row = $query->row();
                $phar = array(
                    'id_user'=> $row->id_user
                );
                $this->session->set_userdata($phar);
                echo "<script>
                alert ('login berhasil');
                window.location='".base_url('admin')."';
                </script>";
            }else{
                echo "<script>
                alert ('form wajib diisi');
                window.location='".base_url('loginadmin')."';
                </script>";
            }
        }
    }

    public function logout()
        {
            $phar = ['id_user'];
            $this->session->unset_userdata($phar);
            redirect('loginadmin');
        }
}
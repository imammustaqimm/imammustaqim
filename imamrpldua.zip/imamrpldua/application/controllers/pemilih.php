<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pemilih extends CI_Controller {
    public function __construct(){
        parent::__construct();
        $this->load->model('kandidat_m');
        $this->load->model('pemilih_m');
    }
    public function index($id = null){
        $data['kandidat'] = $this->kandidat_m->getData();
        $data['pemilih'] = $this->db->get_where('pemilih', ['username' => $this->session->userdata('username')])->row_array();
        $data['cek'] = $this->pemilih_m->cek($id);

        $this->load->view('templates/header');
        $this->load->view('templates/navbarpemilih');
        $this->load->view('pemilih/halamanpemilih', $data);
    }

    public function detail($id)
    {
        $data['pemilih'] = $this->pemilih_m->getId($id);

        $this->load->view('templates/header');
        $this->load->view('pemilih/detail', $data);
    }

    function vote($id)
    {
        $insert = array(
            'id_kandidat' => $id,
            'id_pemilih' => $_SESSION['id_pemilih']
        );

        $this->pemilih_m->vote($insert);

        redirect('pemilih');
    }
}
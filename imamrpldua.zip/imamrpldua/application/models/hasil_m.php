<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class hasil_m extends CI_Model {

    public function getData(){
        $query = "SELECT * FROM hasil as hsl
                JOIN kandidat as kdd ON kdd.id_kandidat = hsl.id_kandidat
                JOIN pemilih as pml ON pml.id_pemilih = hsl.id_pemilih";
                
        return $this->db->query($query)->result_array();
    }

    public function getId($id){
        $query = "SELECT * FROM hasil as hsl
                JOIN kandidat as kdd ON kdd.id_kandidat = hsl.id_kandidat
                JOIN pemilih as pml ON pml.id_pemilih = hsl.id_pemilih
                WHERE `id_hasil` = $id";
        return $this->db->query($query)->row_array();
    }

    public function edit($id){
        $data = [
            'id_kandidat' => $this->input->post('id_kandidat'),
        ];
        $this->db->where('id_hasil', $id);
        $this->db->update('hasil', $data);
    }

    public function hapus($id){
        $this->db->where('id_hasil', $id);
        $this->db->delete('hasil');
    }

}
<h1 class="d-flex justify-content-center mt-5">Halaman Edit Pemilih</h1>
<div class="tambah d-flex justify-content-center mt-5">
    <div class="card" style="width: 50%;">
        <div class="container my-5">
            <form action="adminpemilih/edit" method="POST">

            <input type="hidden" name="id_pemilih" value="<?= $pemilih['id_pemilih'] ?>">

            <div class="mb-3">
                    <label class="form-label">Username</label>
                    <input type="text" name="username" class="form-control" id="username" value="<?= $pemilih['username'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Nama</label>
                    <input type="text" name="nama" class="form-control" id="nama" value="<?= $pemilih['nama'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Password</label>
                    <input type="text" name="password" class="form-control" id="password" value="<?= $pemilih['password'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">NISN</label>
                    <input type="text" name="nisn" class="form-control" id="nisn" value="<?= $pemilih['nisn'] ?>">
                </div>
                <div class="mb-3">
                    <label class="form-label">Alamat</label>
                    <input type="text" name="alamat" class="form-control" id="alamat" value="<?= $pemilih['alamat'] ?>">
                </div>
                <button href="<?=base_url();?> pemilih" type="submit" name="edit" class="btn btn-warning">Edit</button>
                <button type="reset" class="btn btn-danger">Reset</button>
            </form>
        </div>
    </div>
</div>
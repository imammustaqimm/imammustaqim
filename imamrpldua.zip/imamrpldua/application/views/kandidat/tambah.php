<h1 class="d-flex justify-content-center mt-5">Tambah Kandidat</h1>
<div class="tambah d-flex justify-content-center mt-5">
    <div class="card" style="width: 50%;">
        <div class="container my-5">
            <form action="" method="POST">
                <div class="mb-3">
                    <label class="form-label">Nama Ketos</label>
                    <input type="text" name="nama_ketos" class="form-control" id="nama_ketos">
                </div>
                <div class="mb-3">
                    <label class="form-label">Nama Waketos</label>
                    <input type="text" name="nama_waketos" class="form-control" id="nama_waketos">
                </div>
                <div class="mb-3">
                    <label class="form-label">Image</label>
                    <input type="file" name="image" class="form-control" id="image">
                </div>
                <div class="mb-3">
                    <label class="form-label">Visi</label>
                    <input type="text" name="visi" class="form-control" id="visi">
                </div>
                <div class="mb-3">
                    <label class="form-label">Misi</label>
                    <input type="text" name="misi" class="form-control" id="misi">
                </div>
                <button href="<?=base_url();?> kandidat" type="submit" name="tambah" class="btn btn-success">Tambah</button>
                <button type="reset" class="btn btn-danger">Reset</button>
            </form>
        </div>
    </div>
</div>
<nav class="navbar navbar-dark" style="height: 70px; background-color: #9EB8D9;">
  <div class="container-sm">
    <a class="navbar-brand">APLIKASI PEMILIHAN</a>
    <form class="d-flex">
      <a href="<?= base_url('loginadmin/logout') ?>" class="btn btn-danger">Logout</a>
    </form>
  </div>
</nav>
-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Nov 23, 2023 at 04:20 AM
-- Server version: 8.0.30
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `skema`
--

-- --------------------------------------------------------

--
-- Table structure for table `hasil`
--

CREATE TABLE `hasil` (
  `id_hasil` int NOT NULL,
  `id_kandidat` int NOT NULL,
  `id_pemilih` int NOT NULL,
  `tanggal_jam` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `hasil`
--

INSERT INTO `hasil` (`id_hasil`, `id_kandidat`, `id_pemilih`, `tanggal_jam`) VALUES
(3, 8, 6, '2023-11-23 02:43:17'),
(6, 8, 20, '2023-11-23 03:25:01'),
(7, 9, 21, '2023-11-23 03:37:25');

-- --------------------------------------------------------

--
-- Table structure for table `kandidat`
--

CREATE TABLE `kandidat` (
  `id_kandidat` int NOT NULL,
  `nama_ketos` varchar(100) NOT NULL,
  `nama_waketos` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `visi` varchar(100) NOT NULL,
  `misi` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `kandidat`
--

INSERT INTO `kandidat` (`id_kandidat`, `nama_ketos`, `nama_waketos`, `image`, `visi`, `misi`) VALUES
(8, 'GALANG', 'AKSIN', 'Kandidat 1.png', 'asdasdasd', 'asdasdasd'),
(9, 'ANANTA', 'BIMA', 'Kandidat 2.png', 'kajsndaksjdn', 'kjnkjnkjn'),
(11, 'ILMI', 'SULTON', 'Kandidat 3.png', 'qqwertyuiop', 'asdfghjklzxcvbnm');

-- --------------------------------------------------------

--
-- Table structure for table `pemilih`
--

CREATE TABLE `pemilih` (
  `id_pemilih` int NOT NULL,
  `username` varchar(150) NOT NULL,
  `nama` varchar(150) NOT NULL,
  `password` varchar(200) NOT NULL,
  `nisn` varchar(12) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `pemilih`
--

INSERT INTO `pemilih` (`id_pemilih`, `username`, `nama`, `password`, `nisn`, `alamat`) VALUES
(11, 'abdil', 'abdil', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '123123123', 'sdlvkslvknv'),
(12, 'ananta', 'ananta', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '123123123', 'lksjdfksdjv'),
(13, 'gilang', 'gilang', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '12312312', 'clvjknbskdjvds'),
(14, 'dimas', 'dimas', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '123123123', 'alsnkajdbksdbv'),
(15, 'galang', 'galang', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '123123123', 'ksfjgbsjkvbskdv'),
(16, 'imam', 'imam', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '123123123', 'sfvbbdfbdfb'),
(17, 'lukman', 'lukman', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '123123123', 'lcsvjnckvjsv'),
(18, 'bima', 'bima', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '123123123', 'sldjnksjdv'),
(19, 'aksin', 'aksin', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '12123123', 'lvjnskdjfbksdl'),
(21, 'arifh', 'arif', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', '123123', 'sldkvnskjdv');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id_user` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(30) NOT NULL,
  `password` varchar(100) NOT NULL,
  `level` int NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id_user`, `username`, `email`, `password`, `level`) VALUES
(1, 'admin', 'admin@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 1),
(12, 'user', 'user@gmail.com', '40bd001563085fc35165329ea1ff5c5ecbdbbeef', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hasil`
--
ALTER TABLE `hasil`
  ADD PRIMARY KEY (`id_hasil`);

--
-- Indexes for table `kandidat`
--
ALTER TABLE `kandidat`
  ADD PRIMARY KEY (`id_kandidat`);

--
-- Indexes for table `pemilih`
--
ALTER TABLE `pemilih`
  ADD PRIMARY KEY (`id_pemilih`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hasil`
--
ALTER TABLE `hasil`
  MODIFY `id_hasil` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `kandidat`
--
ALTER TABLE `kandidat`
  MODIFY `id_kandidat` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `pemilih`
--
ALTER TABLE `pemilih`
  MODIFY `id_pemilih` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
